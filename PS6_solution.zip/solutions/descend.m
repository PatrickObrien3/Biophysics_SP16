function [locs, L, nsteps, E, fsum, pressure] = descend(cells, locs, L, coeffs, A0, dt, hdt, maxFsum, maxSteps)
%DESCEND Summary of this function goes here
%   Detailed explanation goes here
    if maxSteps <= 0
        maxSteps = 1000;
    end
    
    K = coeffs(1);
    Lambda = coeffs(2);
    Gamma = coeffs(3);
    lastE = NaN;
    lastlocs = locs;
    lastL = L;
    
    for i=1:maxSteps
        nsteps = i;
        [EA, EL, EP, pressures] = cellenergies(A0, cells, locs, L);
        E = [EA, EL, EP] * coeffs';
        if (i > 1) && (lastE < E) && dt > maxFsum
%             fprintf('Trying lower dt%8.2g at step%4d (%8.4g)\n', dt/2, i, E - lastE);
%             locs = lastlocs;
%             L = lastL;
%             E = lastE;
%             [locs, L, nstepsinner, E, fsum, pressure] = ...
%                 descend(cells, lastlocs, lastL, coeffs, A0, dt/1.2, hdt/1.2, maxFsum, maxSteps - i);
%             nsteps = [i, nstepsinner];
%             return
        elseif (i > 1) && (lastE < E)
%             locs = lastlocs;
%             L = lastL;
%             E = lastE;
%             break
        end
        lastE = E;
        lastlocs = locs;
        lastL = L;
        
        pressure = pressures * coeffs';
%         Lfac = max([0.9, 1 - pressure .* hdt]);
        Lfac = 1 - pressure .* hdt;
        [forcesA, forcesL, forcesP] = cellforces(A0, cells, locs, L);
        forces = forcesA .* K + forcesL .* Lambda + forcesP .* Gamma;
        fsum = sum(sum(forces.^2,2)) / length(locs);
        if hdt > 0
            fsum = fsum + pressure.^2;
        end
        
        if fsum < maxFsum
            break;
        end
        
        locs = (locs + (forces.*dt))*Lfac;
%         locs = locs*Lfac + (forces.*dt);
        L = L * Lfac;
    end
    [EA, EL, EP, pressures] = cellenergies(A0, cells, locs, L);
    E = [EA, EL, EP] * coeffs';
    pressure = pressures * coeffs';
end

