function perim = perimeter(ixs, locs, L)
% PERIMETER(ixs, locs, L)
%
% Calculates the perimeter of a polygon in a periodic box of length L.
    perim = 0;
    for i=1:length(ixs)
        ix1 = ixs(i);
        ix2 = ixs(mod(i, length(ixs))+1);
        r1 = locs(ix1, :);
        r2 = locs(ix2, :);
        dr = mod(r1 - r2 + L/2, L) - L/2;
        perim = perim + sqrt(sum(dr.^2));
    end

%     poly = locs(ixs, :);
%     drs = [poly(2:end, :); poly(1, :)] - poly;
%     drs(:, 1) = mod(drs(:, 1) + L(1)/2, L(1)) - L(1)/2;
%     drs(:, 2) = mod(drs(:, 2) + L(2)/2, L(2)) - L(2)/2;
%     perim = sum(sqrt(sum(drs.^2, 2)));
end