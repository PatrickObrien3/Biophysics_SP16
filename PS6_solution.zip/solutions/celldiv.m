function [newcells, newlocs] = celldiv(cells, locs, L, cellix, split1, split2)
%% CELLDIV(cells, locs, L, cellix, split1, split2)
%
% Takes a list of cell vertex indices (CELLS) and their coordinates (LOCS),
% A cell index (CELLIX), and divides that cell in two by creating two
% additional vertices after SPLIT1 and SPLIT2.
%
% Returns a new list of cell vertex indices (NEWCELLS) and vertex locations
% (NEWLOCS).
    
    [N, ~] = size(locs);

    firstcell = cells{cellix};
    if split2 < split1
        temp = split1;
        split1 = split2;
        split2 = temp;
    end
    
    split1b = mod(split1, length(firstcell)) + 1;
    split2b = mod(split2, length(firstcell)) + 1;
    ix1 = firstcell(split1);
    ix1b = firstcell(split1b);
    ix2 = firstcell(split2);
    ix2b = firstcell(split2b);
    
    x1 = locs(ix1, :);
    dr1 = mod(locs(ix1b, :) - x1 + L/2, L) - L/2;
    loc1 = x1 + dr1/2;
    x2 = locs(ix2, :);
    dr2 = mod(locs(ix2b, :) - x2 + L/2, L) - L/2;
    loc2 = x2 + dr2/2;
    
    newlocs = [locs; loc1; loc2];
    
    cell1 = [firstcell(1:split1), N+1, N+2, firstcell(split2+1:end)];
    cell2 = [firstcell(split1+1:split2), N+2, N+1];
    newcells = [cells(1:cellix-1); {cell1}; cells(cellix+1:end); {cell2}];
    
    % OK, now we have divided that cell in two, but the two neighboring
    % cells need to include the new junctions
    
    for i=1:length(newcells)-1
        if i == cellix
            % Ignore daughter cells
            continue
        end
        cell = newcells{i};
        if sum(ismember(cell, [ix1, ix1b])) == 2
            split = find(cell == ix1b);
%             fprintf('Mod 1: %d\n', i);
            newcells{i} = [cell(1:split), N + 1, cell(split+1:end)];
        end
        if sum(ismember(cell, [ix2, ix2b])) == 2
            split = find(cell == ix2b);
%             fprintf('Mod 2: %d\n', i);
            newcells{i} = [cell(1:split), N + 2, cell(split+1:end)];
        end
    end
end