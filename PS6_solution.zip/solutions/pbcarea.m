function A = pbcarea(ixs, locs, L)
% PBCAREA
%
% Calculates the energy from the area elasticity for cells in cellix. 
% Multipy by K to get the correctly normalized amount.
    A = 0;
    r0 = locs(ixs(1), :);
    for i=1:length(ixs)
        ix1 = ixs(i);
        ix2 = ixs(mod(i, length(ixs))+1);
        r1 = mod(locs(ix1, :) - r0 + L/2, L) - L/2;
        r2 = mod(locs(ix2, :) - r0 + L/2, L) - L/2;
        base = r1(1) - r2(1);
        height = (r1(2) + r2(2)) ./ 2;
        dA = base .* height;
        A = A + dA;
        
        % A = A + (r1(end:-1:1) * r2')./2;
   end
end