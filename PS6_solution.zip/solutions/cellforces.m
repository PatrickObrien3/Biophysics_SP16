function [forcesA, forcesL, forcesP] = cellforces(A0, cells, locs, L)
% LINEFORCE
%
% Calculates the forces from the area, line tension, and perimeter.
% Multipy by K, LAMBDA, and GAMMA to get the correctly normalized amount.
    forcesA = zeros(size(locs));
    forcesL = zeros(size(locs));
    forcesP = zeros(size(locs));
    
    Amatr = [0,-1;1,0] ./ 2;
    
    for ix = 1:length(cells)
        verts = cells{ix};
        A = pbcarea(verts, locs, L);
        P = perimeter(verts, locs, L);
        for i=1:length(verts)
            vert0 = verts(mod(i-2, length(verts))+1);
            vert1 = verts(i);
            vert2 = verts(mod(i, length(verts))+1);
            
            r0 = locs(vert0, :);
            r1 = locs(vert1, :);
            r2 = locs(vert2, :);
            dr12 = mod(r1 - r2 + L/2, L) - L/2;
            dr02 = mod(r0 - r2 + L/2, L) - L/2;
            
            l12 = sqrt(sum(dr12.^2));
            if vert1 < vert2
                forcesL(vert1, :) = forcesL(vert1, :) - dr12 ./ l12;
                forcesL(vert2, :) = forcesL(vert2, :) + dr12 ./ l12;
            end
            
            forcesP(vert1, :) = forcesP(vert1, :) - P .* dr12 ./ l12;
            forcesP(vert2, :) = forcesP(vert2, :) + P .* dr12 ./ l12;
            
            forcesA(vert1, :) = forcesA(vert1, :) - (A - A0) .* (Amatr * dr02')';
        end
    end
end