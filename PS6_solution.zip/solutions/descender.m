%% Load Files

locs0 = csvread('random_network.csv');
cell_arr = csvread('random_network_cells.csv');
L0 = [9*sqrt(2/(3*sqrt(3))), 4*sqrt(2/(sqrt(3)))];

A0 = 1;
K = 1;
if ~exist('coeffcase', 'var')
    coeffcase = 1;
end

if coeffcase == 1
    disp('Case I');
    Lambda = 0.12;
    Gamma = 0.04;
elseif coeffcase == 2
    disp('Case II');
    Lambda = 0;
    Gamma = 0.1;
elseif coeffcase == 3
    disp('Case III');
    Lambda = -0.85;
    Gamma = 0.1;
else
    error('Unknown case.');
end

coeffs = [K, Lambda, Gamma];

cells0 = num2cell(cell_arr, 2);

%%
cells = cells0;
locs = locs0;
L = L0;
rng(coeffcase + 2000);

%%
Ndivisions = 72; %360; %168
dt = 0.05;
hdt = 0.0005;
maxF = 1e-4;
maxSteps = 800;
lowdist = 0.05;
totaltransitions = [0 0];
if ~exist('showevery', 'var')
    showevery = 10;
end

[locs, L, nsteps, Emin, fsum, pressure] = descend(cells, locs, L, coeffs, A0, dt, hdt, maxF, maxSteps);
fprintf('Initial minimum energy for %d cells: %.8g\n', length(cells),  Emin / length(cells));
figure(3);
clf;
drawpolys(locs, cells, L);

%%
Es = zeros(Ndivisions, 1);
ns = zeros(Ndivisions, 1);
tic;

for i = 1:Ndivisions
    cellix = randi([1 length(cells)]);
    celllen = length(cells{cellix});
    split1 = randi([1 celllen]);
    split2 = mod(round(split1 + celllen/2 - 1), celllen) + 1;
    [cells, locs] = celldiv(cells, locs, L, cellix, split1, split2);
    [locs, L, nsteps, E, fsum, pressure] = descend(cells, locs, L, coeffs, A0, dt, hdt, maxF, maxSteps);
    ns(i) = ns(i) + sum(nsteps);
    locs1 = locs;
    E1 = E;
    
%     nsteps = nsteps;
    transitions = -1;
    tries = -1;
    while transitions ~= 0
        [cells, locs, T1s, T2s, tries] = transition(cells, locs, L, coeffs, A0, lowdist);
        
        transitions = T1s + T2s;
        if transitions > 0
            totaltransitions = totaltransitions + [T1s, T2s];
            [locs, L, nsteps, E, fsum, pressure] = descend(cells, locs, L, coeffs, A0, dt, hdt, maxF, maxSteps);
            ns(i) = ns(i) + sum(nsteps);
            continue
%             nTsteps = nsteps
        end
    end
    
%     disp([i, nsteps, totaltransitions]);
    
    Es(i) = E / length(cells);
    T1 = totaltransitions(1);
    T2 = totaltransitions(2);
    lbl = sprintf('div%4d:%4d steps (%3d, %3d transitions); %3d tries (f: %8.2g, p %8.2g)', ...
            i, ns(i), T1, T2, tries, fsum,  pressure);
    disp(lbl);
    if length(nsteps) > 1
        disp(nsteps)
    end
        
    if ((showevery > 0) && (mod(i, showevery) == 0))
        figure(3);
        clf;
%         fprintf('bools: %d %d %d', showevery > 0, mod(i, showevery) == 0, i >= 66);
        % drawcells(locs, cells, L, 'k-o');
        drawpolys(locs, cells, L);
        title(lbl);
        drawnow
        pause(0.05);
    end
    
%     if nsteps == maxSteps
%         break
%     end
end
toc;
%%
while 1
    [locs, L, nsteps, E, fsum, pressure] = descend(cells, locs, L, coeffs, A0, dt/100, hdt/100, maxF/100, maxSteps);
    [cells, locs, T1s, T2s, tries] = transition(cells, locs, L, coeffs, A0, lowdist*2);
    fprintf('%4d steps (f: %8.2g, p %8.2g), Transitions: %4d, %4d\n', ...
            nsteps, fsum,  pressure, T1s, T2s);
    figure(3);
    drawpolys(locs, cells, L);
    if T1s + T2s == 0
        break
    end
end

fprintf('E/N: %8.4g\n', E/length(cells));


%%
As = zeros(1, length(cells));
Ps = zeros(1, length(cells));
polyns = zeros(1, length(cells));
Asum = ones(6, 1);
counts = zeros(6, 1);

for cix=1:length(cells)
    A = pbcarea(cells{cix}, locs, L);
    As(cix) = A;
    Ps(cix) = perimeter(cells{cix}, locs, L);
    Pn = length(cells{cix});
    polyns(cix) = Pn;
    if (Pn <= 8) && (Pn >= 3)
        Asum(Pn-2) = Asum(Pn-2) + A;
        counts(Pn-2) = counts(Pn-2) + 1;
    end
%         assert(As(cix) > 0.001);
%         assert(Ps(cix) > 0.001);
end

Ameans = Asum ./ counts;
Ameans_normed = Ameans ./ (sum(Asum) / sum(counts));

figure(60);
clf;
histogram(polyns, [2.5,3.5,4.5,5.5,6.5,7.5,8.5,100.5], ...
    'normalization', 'probability', 'FaceColor', [228,26,28]./255);
hold all;
exp_polys = [1, 6.78, 34.61, 38.28, 14.28, 2.17, 0.06] / 100;
exp_polys_err = [0.77, 4.176, 4.06, 6.29, 3.36, 1.76, 0.24] / 100;
errorbar(3:9, exp_polys, exp_polys_err, ...
    'o-', 'Color', [0.3,0.7,0.3], 'Linewidth', 3);

ylim([0, 0.45]);
xlim([2.5, 9.5]);
mean(polyns)

xlabel('Polygon Sides');
ylabel('$P_n$','Interpreter','Latex');
legend('Simulation', 'Experiment', 'location', 'northwest');
fname = sprintf('polygons-compared-case%d-n%d.eps', coeffcase, length(cells));
hgexport(gcf, fname);

ps = Ps ./ sqrt(As);
p0 = mean(ps);
pstd = std(ps);
p_error_in_mean = pstd / sqrt(length(ps));
fprintf('p0 = %.3g +- %.3g (EIM: +- %.3g)\n', p0, pstd, p_error_in_mean);
fprintf('Expected p0: %.3g\n', -Lambda / (2 .* Gamma .* sqrt(A0)));

[EA, EL, EP, pressures] = cellenergies(A0, cells, locs, L);
E = [EA, EL, EP] * coeffs';
% disp(E);
% disp(EA.*K);
disp(EL.*Lambda + EP.*Gamma);

EA = K./2 .* sum((As - A0).^2);
P0 = -Lambda / (2 .* Gamma);
EPL = sum(Gamma./2 .* (Ps - P0).^2 + Lambda.^2./(8.*Gamma));
% disp(EA + EPL);
% disp(EA);
disp(EPL);

%%
figure(61);
clf;
exp_areas = [0.56, 0.82, 1.08, 1.36, 1.52];
exp_areas_err = [0.02, 0.01, 0.01, 0.02, 0.05];
errorbar(4:8, exp_areas, exp_areas_err,  ...
    'o-', 'Color', [0.3,0.7,0.3], 'Linewidth', 2);
hold all;
plot(4:8, Ameans_normed(2:end), 'o-', 'Color', [0.9, 0.1, 0.1], 'Linewidth', 3);
ylim([0, 2.5]);
xlabel('Polygon Sides');
ylabel('$\left<A_n\right> / \left<A\right>$','Interpreter','Latex');
legend('Experiment', 'Simulation', 'location', 'northwest');
fname = sprintf('areas-compared-case%d-n%d.eps', coeffcase, length(cells));
hgexport(gcf, fname);

%%
figure(70);
clf;
drawpolys(locs, cells, L);
fname = sprintf('cell-shapes-case%d-n%d.eps', coeffcase, length(cells));
hgexport(gcf, fname);

%% Calculate edges, faces, vertices
faces = length(cells);
vertices = length(locs);
edges = 0;
for i=1:length(cells)
    edges = edges + length(cells{i});
end
edges = edges / 2;

disp(faces)
disp(vertices)
disp(edges)

M = faces + vertices - edges
