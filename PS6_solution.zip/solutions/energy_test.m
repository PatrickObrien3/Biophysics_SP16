clear;
locs0 = csvread('random_network.csv');
cell_arr = csvread('random_network_cells.csv');
L0 = [9*sqrt(2/(3*sqrt(3))), 4*sqrt(2/(sqrt(3)))];
A0=1;
cells0 = num2cell(cell_arr, 2);

coeffs = [1, 1, 1];

[EA, EL, EP, pressures] = cellenergies(A0, cells0, locs0, L0);
E = [EA, EL, EP] * coeffs';

[forcesA, forcesL, forcesP] = cellforces(A0, cells0, locs0, L0);


