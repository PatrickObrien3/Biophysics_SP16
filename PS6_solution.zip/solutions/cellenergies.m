function [EA, EL, EP, pressures] = cellenergies(A0, cells, locs, L)
    EA = 0;
    EL = 0;
    EP = 0;
    pressures = [0, 0, 0];
    
    for ix = 1:length(cells)
        verts = cells{ix};
        A = pbcarea(verts, locs, L);
        P = perimeter(verts, locs, L);
        EL = EL + P/2;
        EP = EP + P.^2/2;
        EA = EA + (A - A0).^2 / 2;
        pressures(1) = pressures(1) + (A.^2 - A0.*A) * 2;
    end
    pressures(2) = EL;
    pressures(3) = 2*EP;
end