% Biophysics PS3

% The Freely Jointed Chain (FJC) Model

%% A) Creating the Chains

% Set number of polymers, number of configurations / runs
N = 200; m=500;

% Create a matrix of N-1 angles, which will be the angle from the
% horizontal for each separation vector
angs = rand(N-1, m)*2*pi;
% cos(angs), sin(angs) will produce the separation vectors; the cumsum
% gives us the (x,y) of each point relative to the first point in the
% chain, so we add in some zeros to start at the origin
xs = [zeros(1,m); cumsum(cos(angs))];
ys = [zeros(1,m); cumsum(sin(angs))];

figure(1); clf;
plot(xs(:, 1:6), ys(:, 1:6));
axis equal;
axis off;
hgexport(gcf, 'PS3-A.eps');

%% B) FJC Statistics
% The end-to-end vectors are therefore just the last rows of the xs, ys
% matrices
ends = [xs(end,:);ys(end,:)];
% 'ends' is now a 2xm matrix, with the rows being x-coordinates, 
% y-coordinates of each polymer end-to-end vector. Now we want the
% end-to-end distance:
endtoend = sqrt(sum(ends.^2));

fprintf('<R vector>:            [%.3f, %.3f]\n', mean(ends,2));
fprintf('<R^2>:                 %.3f (N: %.2f)\n', [mean(sum(ends.^2)), N]);

% Let's make a histogram of the end-to-end distances...
figure(2); clf; box on;
[n, xout] = hist(endtoend, 20);
stairs(xout, n / mean(diff(xout)) / m, 'linewidth', 2);
hold on;
set(gca, 'fontsize', 20, 'linewidth', 2)

% And calculate the theoretical values...
yout = (2/N) * xout.*exp(-xout.^2 / N);
plot(xout, yout, 'k--', 'linewidth', 2);

legend '|R| (simulated, 500 runs)' '|R| (Theoretical)';
xlabel('$|\vec{R}|$','Interpreter','Latex', 'fontsize', 20);
ylabel('$P\left(\left|\vec{R}\right|\right)$','Interpreter','Latex', 'fontsize', 20);
title 'End-to-End Distance for the 2D FJC Model, N=200';

hgexport(gcf, 'PS3-B.eps');

