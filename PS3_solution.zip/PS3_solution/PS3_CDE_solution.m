% Biophysics PS3
clear;
clc;

%The Freely Rotating Chain (FRC) Model

%% C) Plotting a single chain
figure(3); clf; 
ts = frc(pi/8,200,1);
Rs=[[0;0;0] cumsum(ts,2)];
plot3(Rs(1,:),Rs(2,:),Rs(3,:), '.-', 'LineWidth',2, 'markersize', 20);
set(gca, 'linewidth', 2);
axis equal;
hgexport(gcf, 'PS3-C.eps');

%% D) Analysis of <r_i dot r_j> 
% D 1-3)
N=200; m=1000;
thetas = pi/3;
sepvecs = frc(thetas, N, m);
% Make an Nxm matrix of |r_{i,j}|, where r_{i,j} is the jth separation
% vector in the ith configuration
abstij = sqrt(sum(sepvecs.^2,1));
meantij = mean2(abstij);
stdtij = std2(abstij);

fprintf('|rij|: %.3g +- %.3g ; expected 1\n', mean(mean(abstij)), stdtij);
% The expected value for the mean should be 1, which is the bond length.
% The very small standard deviation is from the round error when calculating |r_i| 

% Now find neighboring vectors:
tijtijplus1=sum(sepvecs(:,1:end-1,:).*sepvecs(:,2:end,:),1);

fprintf('r_i,j with r_i,j+1: %.3g +- %.3g ; expected cos(theta)=%.3g\n', ...
        mean2(tijtijplus1), std2(tijtijplus1), cos(thetas));
% The expected value for the mean should be cos(theta), where theta is the
% bond angle
    
    
% D 4-6) General <r_i dot r_j> as a function of |i-j|
% First we write down what thetas we want
thetas=[pi/100 pi/8 pi/3 pi/2, 2*pi/3];
thetastrs = {'\pi/100', '\pi/8', '\pi/3', '\pi/2', '2\pi/3'};
Ntheta=length(thetas);

plothandles=[];
figure(4); clf; 
box on; hold on;
set(gca, 'linewidth', 2, 'fontsize', 20);
for i=1:(Ntheta)
    sepvecs=frc(thetas(i), N, m);
    
    % Now we generate an Nx1 matrix of <r_n,i dot r_n,i+d>, where 
    % 0 <= d < N and we average over all values of n and i
    ijs = zeros(N, 1);
    for d = 0:N-1
        dotproduct = sum(sepvecs(:,1:N-d,:).*sepvecs(:, 1+d:N,:),1);
        ijs(d+1) = mean(mean(dotproduct));
    end
    
    
    % Now we plot, and save the handle for later (the legend)
    % First the theory plot...
    iminusjs = 0:N-1;
    theoryplot = plot(iminusjs, cos(thetas(i)).^iminusjs, 'k:', 'LineWidth',2);
    
    % Then the simulation
     plothandles(i) = plot(iminusjs, ijs, '.', 'MarkerSize', 24, 'LineWidth',2);
    
    % Find the (single) last place where <r_i dot r_i+d> > 1/e, and call that
    % the persistence length
    lp = find(ijs > exp(-1), 1, 'last');
    % And calculate the theoretical value
    lptheor = -1/log(cos(thetas(i)));
    
    % just a flourish: the legend needs latex, where you use '\pi', but for
    % printing, we want the character for it
    thetastr = strrep(thetastrs{i}, '\pi',native2unicode([207,128], 'utf8'));
    % now print the two to main output
    fprintf('%8s: %6.1f, %6.1f\n', thetastr, lp, lptheor);
end
axis([0 20 -1 1]);
legend([plothandles theoryplot], [thetastrs {'Theoretical'}], ...
        'Location', 'SouthEast');
xlabel('|i-j|', 'Interpreter','tex');
ylabel('<r_i \cdot r_j>', 'Interpreter','tex');
title('<r_i \cdot r_j> v.s. |i-j| for Various Bond Angles', 'Interpreter','tex');
hgexport(gcf, 'PS3-D.eps');

% D.6
% The given expression is only valid for theta less than pi/2. For a given
% theta less than pi/2, <r_i dot r_{i+d}> goes down with d increasing. The d at
% which <r_i dot r_{i+d}> reach 1/e is defined as persistence length lp. The lp
% becomes larger for a smaller theta. When a theta greater than pi/2, the
% <r_i dot r_{i+d}> would fluctulate with d increasing.


%% E) sqrt(<R^2>) vs. lp
Ntheta=20;
N=200; 
m=1000;
simlp = logspace(-2,4,Ntheta);
costhetavals = exp(-1./simlp);
dists = zeros(1,Ntheta);

% Generate the values
for i=1:Ntheta
    sepvecs = frc(acos(costhetavals(i)), N, m);
    endtoendvectors = squeeze(sum(sepvecs,2));
    dists(i) = mean(sum(endtoendvectors.^2,1));
end

% Now we plot
figure(5); clf;
box on; hold on;
set(gca, 'linewidth', 2, 'fontsize', 20);
set(gca, 'xscale', 'log');
semilogx(simlp, sqrt(dists), '.', 'MarkerSize', 32);


% Generate many more theta values for the theoretical lines
lp = logspace(-2,4,Ntheta);
costheta = exp(-1./lp);
FRCRsq = N*((1+costheta) ./ (1-costheta) - ...
    ((2.*costheta.*(1-costheta.^N)) ./ ...
    (N .* (1 - costheta).^2)));

% The theoretical lines
Rmax = N;
wrmR2 = 2.*lp.*Rmax - (2 * (lp.^2).*(1-exp(-Rmax./lp)));
semilogx(lp, sqrt(FRCRsq), 'k-', 'linewidth', 2, 'markersize', 12);
semilogx(lp, sqrt(wrmR2), '--', 'linewidth', 2, 'markersize', 12);
%ylim([0,N])
%xlim([1e-2 1e4])
xlabel('Persistence Length', 'interpreter', 'tex');
ylabel <R^2>
legend('Simulation', 'FRC', 'WLC', ...
    'Location','SouthEast')
title('<R^2> for the Freely Rotating Chain, N=200')
hgexport(gcf, 'PS3-E.eps');

% E.5
% FRC model is accurate for all range of lp, while WLC model 
% is only accurate for relative large persistence length. The reason 
% is that the theta is assumed to be very small for WLC model, 
% which would lead to a large persistence length. 

