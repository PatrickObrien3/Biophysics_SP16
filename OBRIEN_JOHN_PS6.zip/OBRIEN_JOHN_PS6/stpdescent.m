%% Steepest Descent
%% Patrick O'Brien
%% Biophysics Final


function [newlocs, Evals, newL] = stpdescent(cells, locs, L, coeffs, A0, epsilon, epsilonL, fs, E0, dh, key)
% key will be used to determine which steepest descent conditions to use
% for the while loop. key = 1 will be fore part 5, and else will be part 9.

%% Set-up and renaming:

% K = coeffs(1);
% lambda = coeffs(2);
% gamma = coeffs(3); 

Evals(1) = E0;
Evals(2) = E0;

newL = L;
newlocs = locs;

i = 1;


if key == 1
    while sqrt(sum(sum(fs.^2))) > 1e-6 
        
        % calculate energy of current state i. 
        [Etotnew, ~, ~, ~, Atot, Ptot, ~] = cellenergies(newL, A0, coeffs, cells, newlocs);
        
        Evals(i+1) = Etotnew;
        
        i = i+1;
        
        [fs] = cellforces(newL, A0, coeffs, cells, newlocs, Atot, Ptot);
        
%         newlocs = (1 - epsilonL.*sum(h)).*(newlocs + epsilon.*Fnew);
        newlocs = newlocs + epsilon.*fs;
        
        if mod(i,10000) == 0
            disp(['made it through trial number: ',num2str(i)]);
            disp(['Energy now at: ', num2str(Evals(i))]);
            disp(['Forces term now at: ', num2str(sqrt(sum(sum(fs.^2))))]);
        end
    end
    
elseif key == 2  % For cases where a barostat are needed: 
    while ((1/(length(cells))*sum(sum(fs.^2))) + (sum(dh)).^2) > 1e-6 && i < 250000 
        
        % calculate energy of current state i. 
        [Etotnew, ~, ~, ~, Atot, Ptot, dh] = cellenergies(newL, A0, coeffs, cells, newlocs);
        
        Evals(i+1) = Etotnew;
        
        i = i+1;
        
        [fs] = cellforces(newL, A0, coeffs, cells, newlocs, Atot, Ptot);
        
        % Update the new positions and box sizes with the barostat scaling
        % factors: 
        
        newlocs = (1 - epsilonL .* ( sum(dh) ) ) .* (newlocs + epsilon.*fs);
        newL = (1 - epsilonL .* ( sum(dh) ) ).*newL;
        
        if mod(i,20000) == 0
            disp(['made it through trial number: ',num2str(i)]);
            disp(['Energy/N_c now at: ', num2str(Evals(i)./(length(cells)))]);
            disp(['Check term now at: ', num2str(((1/(length(cells))*sum(sum(abs(fs).^2))) + (sum(dh)).^2))]);
            
        end
    end
elseif key == 3
    while ((1/(length(cells))*sum(sum(fs.^2))) + (sum(dh)).^2) > 1e-4 && i < 800 
        
        % calculate energy of current state i. 
        [Etotnew, ~, ~, ~, Atot, Ptot, dh] = cellenergies(newL, A0, coeffs, cells, newlocs);
        
        Evals(i+1) = Etotnew;
        
        i = i+1;
        
        [fs] = cellforces(newL, A0, coeffs, cells, newlocs, Atot, Ptot);
        
        % Update the new positions and box sizes with the barostat scaling
        % factors: 
        
        
%         if Evals(i) < Evals(i-1)
%             newlocs = (1 - epsilonL .* ( sum(dh) ) ) .* (newlocs + epsilon.*fs);
%             newL = (1 - epsilonL .* ( sum(dh) ) ).*newL; 
%         else
%             i = 10006;
%         end
        newlocs = (1 - epsilonL .* ( sum(dh) ) ) .* (newlocs + epsilon.*fs);
        newL = (1 - epsilonL .* ( sum(dh) ) ).*newL;
        

        
%         if mod(i,200) == 0
%             disp(['made it through trial number: ',num2str(i)]);
%             disp(['Energy/N_c now at: ', num2str(Evals(i)./(length(cells)))]);
%             disp(['Check term now at: ', num2str(((1/(length(cells))*sum(sum(abs(fs).^2))) + (sum(dh)).^2))]);
%             
%         end
          
    end
end


% disp(['final trials used was: ', num2str(i)]);
% disp(['check term: ', num2str( ((1/(length(cells))*sum(sum(abs(fs).^2))) + (sum(dh)).^2))]);
end