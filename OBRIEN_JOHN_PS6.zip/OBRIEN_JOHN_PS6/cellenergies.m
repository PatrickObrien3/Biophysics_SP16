%% Cell energies function
%% Patrick O'Brien 
%% Biophysics Final 
%% May 10th, 2016

function [Etot, EA, ET, EP, Atot, Ptot, dh] = cellenergies(L, A0, coeffs, cells, locs)
% 
% L is boundary conditions (2x1). A0 is optimal area, A and Tau are for
% their respective functions. cells is cell array of cells with vertices,
% locs is their respective positions. outputs are for EA which is the
% energy from area or elasticity, ET is the energy from tension, EP is the
% energy from contractility or perimeter. This also returns Atot which is
% the area for each cell (24x1), and Ptot, which is the perimeter for each
% cell (24x1). 


%% Energy calculation set up

K = coeffs(1);
lambda = coeffs(2);
gamma = coeffs(3);

numcells = length(cells); % gives number of cells to sum over:  
Ptot = zeros(numcells,1);
Atot = zeros(numcells,1);
dh = zeros(1,3);

%% Function

for i = 1:numcells % loop through all cells
    [~, numvertices] = size(cells{i}); % find number of vertices for that cell
    vertices = cells{i}; % get vertex numbers, not used now. 
    vlocs = locs(cells{i},:); % get positions of this cells vertices
    cell_per = 0; % Start with Tcell = 0 
    
    r0 = vlocs(1,:);
    area = 0; 
    for j = 1:numvertices % take care of all but the last vertex to the first
        k = mod(j-1, numvertices)+1;
        kp1 = mod(j-1+1,numvertices)+1;
        dr = (mod(vlocs(k,:) - vlocs(kp1,:) + L/2, L) - L/2);
        cell_per = cell_per + sqrt(sum(dr.^2));
        
        rk = mod(vlocs(k,:) - r0 + L/2,L)- L/2;
        rkp1 = mod(vlocs(kp1,:) - r0 + L/2, L)- L/2;
        
        xdif = rk(1)-rkp1(1);
        yavg = (rk(2) + rkp1(2))./2;
        area = area + xdif.*yavg;

  
    end
    Ptot(i) = cell_per;
    Atot(i) = area;
end

EP = sum( (gamma./2).*(Ptot.^2) );
ET = (lambda./2)*sum(Ptot);
EA = sum((K./2)*(Atot-A0).^2);


Etot = EP + ET + EA;

dh(1) = ( sum( 2.*K.*( Atot.^2 - Atot.*A0) ) );
dh(2) = ET; 
dh(3) = 2.*EP;


end



