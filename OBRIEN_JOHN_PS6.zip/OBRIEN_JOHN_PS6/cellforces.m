%% Cell Forces
%% Patrick O'Brien
%% Biophysics Final

function [Ftot, FA, FT, FP] = cellforces(L, A0, coeffs, cells, locs, Atot, Ptot)



%% Function set-up



K = coeffs(1);
lambda = coeffs(2);
gamma = coeffs(3);

FA = zeros(size(locs));
FT = zeros(size(locs));
FP = zeros(size(locs));

numcells = length(cells); % gives number of cells to sum over:

for i = 1:numcells
    [~, numvertices] = size(cells{i}); % find number of vertices for that cell
    vertices = cells{i}; % get vertex numbers, not used now. 
    vlocs = locs(cells{i},:); % get positions of this cells vertices
   
    for j = 1:numvertices
        
        % Get absolute vertex number to store force later:
        jvert = vertices(j);
        
        % Get correct indices:
        k = mod(j-1, numvertices)+1;
        kp1 = mod(j-1+1,numvertices)+1;
        km1 = mod(j-1-1,numvertices)+1;
        
        % locs of k, k+1, k-1:
        kloc = vlocs(k,:);
        kploc = vlocs(kp1,:);
        kmloc = vlocs(km1,:);
%         disp(['k = ', num2str(k), ' kp = ', num2str(kp1),...
%             ' km = ', num2str(km1)])
%         disp(['vertex: ', num2str(jvert)])
        
        % distance between k, k+1
        drp = mod(kloc - kploc +L/2, L) - L/2;
%         drp_normed = normed(drp);
        drp_normed = drp./sqrt(sum(drp.^2));
        
        % distance betwwn k, k-1
        drm = mod(kloc - kmloc + L/2, L) - L/2;
%         drm_normed = normed(drm);
        drm_normed = drm./sqrt(sum(drm.^2));
        
        % FA: Area/Elasticity Force
        FA(jvert,:) = FA(jvert,:) - (K.*(Atot(i) - A0.^2).*(-1/2).*...
            ([0 1; -1 0]*(drp - drm)'))';
        
        
        % FT: Tension Force
        FT(jvert,:) = FT(jvert,:) - ...
            lambda.*(drp_normed) - lambda.*(drm_normed);
        
        % FP: Perimeter/Contractility force
        FP(jvert,:) = FP(jvert,:) -...
            drp_normed.*gamma.*Ptot(i) -...
            drm_normed.*gamma.*Ptot(i);
        
    end
    
    
    
end

FT = FT./2; 

Ftot = FA + FT + FP;

end

function v = normed(input)
% Returns the vectors in matrix v, normalized along the second axis.
    normval = sqrt(sum(input.^2, 2));
    v = input ./ [normval, normval];
end





