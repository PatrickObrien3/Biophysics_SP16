%% Biophysics Problem Set 06
%% Author: Patrick O'Brien
%% Date: 05/11/16


clear 
close all
%% 1. Load in random_network and random_network_cells and Plot Cells
casevals = [1, 0.12, 0.04; 1, 0.0, 0.1; 1, -0.85, 0.1];

cell_arr = csvread('random_network_cells.csv');
cells = num2cell(cell_arr, 2);

locs = csvread('random_network.csv');
% Lx = 9*sqrt(2/(3*sqrt(3))); 
% Ly = 4*sqrt(2/(sqrt(3))); 
L = [5.58, 4.3];
drawpolys(locs,cells,L)
title('Output 1: Initial Network')

%% 2. Calculate Energy for initial conditions

A0 = 1;
% K = 1; 
% lambda = 1; % Problem with derivative 
% gamma = 1; % might also have problem... 
coeffs = [1, 1, 1];

% function [ET, EP] = cellenergies(L, A0, A, Tau, cells, locs)

[E0, EA, ET, EP, Atot, Ptot, ~] = cellenergies(L, A0, coeffs, cells, locs);
%function [EA, ET, EP] = cellenergies(L, A0, A, K,  gamma, cells, locs)

% Values are close to the ones given in the handout. 
%% 3. Calcualte Forces for initial conditions

% Note: mod(i-1,6)+1 works for all vals. 

% [FA, FT, FP] = cellforces(L, A0, lambda, K,  gamma, cells, locs, Atot, Ptot)

[F0, FA, FT, FP] = cellforces(L, A0, coeffs, cells, locs, Atot, Ptot);
% [F_elastic, F_tension, F_contractile] = calculate_forces(cells, locs, L, coeffs, A0, L_perim, area)

%% 4. Move positions and calculate energy again
epsilon = 1e-6;
locs1 = locs + epsilon.*F0; 

E1 = cellenergies(L, A0, coeffs, cells, locs1);

dE = (E0-E1)./ (epsilon.*sum(sum(F0.^2)));
% Output 4.1: 
disp([' With a value of 1e-6 for epsilon dE = ', num2str(dE)])

%% 5. Steppest Descent with lambda = 0.85, gamma = 0.1, epsilon = 0.05
% output is a plot of vertex positions and connections as in figure 2 and
% the energy as a function of time. 

% coeffs = [K, lambda, gamma];
coeffs(2) = -0.85;
coeffs(3) = 0.1;
epsilon = 0.05; 
h = 0; 
epsilonL = 0; 
key = 1;

% [newlocs, Evals, newL] = stpdescent(cells, locs, L, coeffs, A0, epsilon, epsilonL, fs, E0, h, key)

% calculate force again with new val
[Ftot] = cellforces(L, A0, coeffs, cells, locs, Atot, Ptot);
[newlocs, Evals, ~] = stpdescent(cells, locs, L, coeffs, A0, epsilon, epsilonL, Ftot, E0, h, key);

%% Output 5.a: Make a plot of the vertices and their connections

drawpolys(newlocs, cells, L); 
title('Output 5.1: Case III Minimization')

%% Output 5.b: Plot E(t)./Nc*K*A0.^2 vs. time (steps)

[~,steps] = size(Evals); 
Et = Evals./(length(cells).*coeffs(1).*(A0.^2));

figure
semilogx(1:steps-1,Et(2:end), 'LineWidth', 2)
title('Output 5.2: Energy as function of time for Case III')
xlabel('time(steps)')
ylabel('E/(N_c*K*A0^2)')

%% 6. Starting with soft network from part 5. Relax to a hexagonal network
% Use values of lambda = 0.12KA0^(2/3), gamma = 0.04KA0. 
% Note: with area A0, side length of each hexagon shoudl be l =
% 12^(1/4)./3*sqrt(A0), and perimeter = 6l = 2(12^(1/4))*sqrt(A0) therefore
% expect EA./Nc*K*A0^2 = 0, ET./Nc*k*A0^2 = 1.86121 lambda./K*A0^3/2, and
% EP./Nc*K*A0^2 = 6.9282 gamma./K*A0. Therefore, total energy should be
% about E./Nc*K*A0^2 = 0.5004. 

% set lambda = 0.12; 
coeffs(2) = 0.12;
% set gamma = 0.04;
coeffs(3) = 0.04;

% use newlocs and the updated coeffs to determine the energy for input:
[E6input, ~, ~, ~, Atot, Ptot, ~] = cellenergies(L, A0, coeffs, cells, newlocs);
% and calculate the force for the input: 
[Ftot] = cellforces(L, A0, coeffs, cells, newlocs, Atot, Ptot);

[newlocs6, Evals6, ~] = stpdescent(cells, newlocs, L, coeffs, A0, epsilon, epsilonL, Ftot, E6input, h, key);

%% Output 6.a: plot of cells with drawpolys.m
drawpolys(newlocs6,cells, L)
title('Output 6.1: Case I after Case III relaxation')

%% Output 6.b: Plot E(t)./Nc*K*A0
% 6.9282 gamma./K*A0

[~,steps6] = size(Evals6); 
Et6 = Evals6./(length(cells).*coeffs(1).*(A0.^2));

figure
semilogx(1:steps6-1,Et6(2:end), 'LineWidth', 2)
title('Output 6.2: Energy as function of time for Case I')
xlabel('time(steps)')
ylabel('E/(N_c*K*A0^2)')

%% 6. Sanity check: 
% Use values of lambda = 0.12KA0^(2/3), gamma = 0.04KA0. 
% Note: with area A0, side length of each hexagon shoudl be l =
% 12^(1/4)./3*sqrt(A0), and perimeter = 6l = 2(12^(1/4))*sqrt(A0) therefore
% expect EA./Nc*K*A0^2 = 0, ET./Nc*k*A0^2 = 1.86121 lambda./K*A0^3/2, and
% EP./Nc*K*A0^2 = 6.9282 gamma./K*A0. Therefore, total energy should be
% about E./Nc*K*A0^2 = 0.5004.
[E6, EA6, ET6, EP6, Atot6, Ptot6, ~] = cellenergies(L, A0, coeffs, cells, newlocs6);

% Check EA./Nc*K*A0^2 = 0
check1 = EA6./(length(cells).*coeffs(1).*(A0.^2));
disp(['The value for elasticity energy is close to zero: ', num2str(check1)])

% Check ET./Nc*k*A0^2 = 1.86121 lambda./K*A0^3/2 
check2 = (ET6./(length(cells).*coeffs(1).*(A0.^2)))./coeffs(2);
disp(['The value for tension energy is close to 1.86121: ', num2str(check2)])

% Check EP = 6.9282
check3 = (EP6./(length(cells).*coeffs(1).*(A0.^2)))./coeffs(3);
disp(['The value for contractility energy is close to 6.9282: ', num2str(check3)])

% Check Etot = 0.5004
check4 = E6./(length(cells).*coeffs(1).*(A0.^2));
disp(['The value for total energy is close to 0.5004: ', num2str(check4)])

%% 7. Adding a Barostat
% To do this, added a function dh 'derivative of E with respect to h' into
% the energy calculation and into the steepest descent (accessed when the
% key is not == 1. 

% Running the barostat and verification with Case I and Case II. Case III
% does not reach hexagonal packing. 

% I set the steepest descent to run with conditions matching those in Part
% 9 later (Table 1), might have to readjust if not good enough to reach relaxation.
% Also, using value of epsilonL from later (0.001) and epsilon (0.05)

% All the same for both cases: 
 
key = 2; 

% VERY IMPORTANT TO CHECK THE KEY
%% 7.a Checking Barostat with Case I Parameters
% Starting from the original positions and energies

% Case I lambda and gamma: 
coeffs(2) = 0.12; 
coeffs(3) = 0.04; 

%% 7.a.i Checking if Case I derivative is close: 

epsilon = 1e-6;   % Set epsilon small so derivative is close: 
epsilonL = 0.001; 

% calculate energy
[E7i, ~, ~, ~, Atot7, Ptot7, dh] = cellenergies(L, A0, coeffs, cells, locs);
% calculate forces
fs7 = cellforces(L, A0, coeffs, cells, locs, Atot7, Ptot7);

% move positions and expand box: 
locs7i = (1 - epsilonL.*(sum(dh))).*(locs +epsilon.*fs7);
newL = (1 - epsilonL.*(sum(dh))).*L;

% calculate new energy
[E72, ~, ~, ~, Atot72, Ptot72, dh2] = cellenergies(newL, A0, coeffs, cells, locs7i);
rhs = E7i - epsilon.*sum(sum(fs7.^2)) - epsilonL.*(sum(dh)).^2;

[E72, rhs]
% They should be approximately equal, and they appear to be.
disp([' Case I verification: left hand side: ', num2str(E72), ...
    ' is about equal to right hand side: ', num2str(rhs)])

E72 - rhs
%% 7.a.ii Now do steepest descent of Case I: 

% change epsilon back to 0.05
epsilon = 0.05;

[E7Iinput, ~, ~, ~, Atot, Ptot, dh] = cellenergies(L, A0, coeffs, cells, locs);
% and calculate the force for the input: 
[F7I] = cellforces(L, A0, coeffs, cells, locs, Atot, Ptot);

[newlocs7I, Evals7I, newL7I] = stpdescent(cells, locs, L, coeffs, A0, epsilon, epsilonL, F7I, E7Iinput, dh, key);
% Use original locs and L: 
% Used all 800 trials: 

drawpolys(newlocs7I, cells, newL7I)
title('Output 7.a: Case I with Barostat')

%% 7.bi Check if Case II derivative is close:
% Starting from original positions and energies

% Case II lambda and gamma:
coeffs(2) = 0.0; 
coeffs(3) = 0.01; 

epsilon = 1e-6;       % Set epsilon small so derivative is close: 
epsilonL = 0.001; 

% calculate energy
[E7i, ~, ~, ~, Atot7, Ptot7, dh] = cellenergies(L, A0, coeffs, cells, locs);
% calculate forces
fs7 = cellforces(L, A0, coeffs, cells, locs, Atot7, Ptot7);

% move positions and expand box: 
locs7i = (1 - epsilonL.*(sum(dh))).*(locs +epsilon.*fs7);
newL = (1 - epsilonL.*(sum(dh))).*L;

% calculate new energy
[E72, ~, ~, ~, Atot72, Ptot72, dh2] = cellenergies(newL, A0, coeffs, cells, locs7i);
rhs = E7i - epsilon.*sum(sum(fs7.^2)) - epsilonL.*(sum(dh)).^2;

[E72, rhs]
% They should be approximately equal, and they appear to be.
disp([' Case II verification: left hand side: ', num2str(E72), ...
    ' is about equal to right hand side: ', num2str(rhs)])

E72 - rhs

%% 7.bii Steepest Descent with Case II Parameters

% change epsilon back to 0.05
epsilon = 0.05;

[E7IIinput, ~, ~, ~, Atot, Ptot, dh] = cellenergies(L, A0, coeffs, cells, locs);
% and calculate the force for the input: 
[F7II] = cellforces(L, A0, coeffs, cells, locs, Atot, Ptot);

[newlocs7II, Evals7II, newL7II] = stpdescent(cells, locs, L, coeffs, A0, epsilon, epsilonL, F7II, E7IIinput, dh, key);
% Use original locs and L: 
% Used all 800 trials: 

drawpolys(newlocs7II, cells, newL7II)
title('Output 7.b: Case II with Barostat')

%% 8. Cell Division
% Using Wendell's code. 

split1 = 3; 
split2 = 6;
epsilon = 0.05; 
epsilonL = 0.001;

 
%% Going to try with initial network to see if celldivision code works:

cellix = randi([1 length(cells)],1,1);
disp(['split cell: ', num2str(cellix)])
[newcells8, newlocs8] = celldiv(cells, locs, L, cellix, split1, split2);

drawpolys(newlocs8, newcells8, L);
title('Test division of initial network')

%% 9. Run full models for Case I, II, and III

key = 3; 

split1 = 1; 

epsilon = 0.05; 
epsilonL = 0.001;

lowdist = 0.05;
casevals = [1, 0.12, 0.04; 1, 0.0, 0.1; 1, -0.85, 0.1];

divisions = 72;
for j = 1:3
    
    coeffs = casevals(j,:);
    newcells9 = cells;
    newlocs9 = locs;
    L9 = L;

    [E9, ~, ~, ~, Atot9, Ptot9, dh9] = cellenergies(L9, A0, coeffs, newcells9, newlocs9);
    fs9 = cellforces(L9, A0, coeffs, newcells9, newlocs9, Atot9, Ptot9);
    [newlocs9, Evals9, L9] = stpdescent(newcells9, newlocs9, L9, coeffs, A0, epsilon, epsilonL, fs9, E9, dh9, key);
    
    pass = 1; 
    
    for i = 1:divisions % 72 at first
        pass =1;
        cellix = randi([1 length(newcells9)],1,1); %random cell for division
%         disp(['split cell: ', num2str(cellix)]) % Display the new cell:
        if length(newcells9{cellix}) < 3
            disp('length too small!')
            pass = 0;    
        end
        
        if pass == 1
            
            split2 = round(length(newcells9{cellix})/2)+1;
            [newcells9, newlocs9] = celldiv(newcells9, newlocs9, L9, cellix, split1, split2);
            
            % Now that have division, enter while loop:
            %     function [newcells, newlocs, T1s, T2s, tries] = transition(cells, locs, L, coeffs, A0, lowdist)
            %         disp(['cells before = ', num2str(length(newcells9))])
            
            [E9, ~, ~, ~, Atot9, Ptot9, dh9] = cellenergies(L9, A0, coeffs, newcells9, newlocs9);
            fs9 = cellforces(L9, A0, coeffs, newcells9, newlocs9, Atot9, Ptot9);
            [newlocs9, Evals9, L9] = stpdescent(newcells9, newlocs9, L9, coeffs, A0, epsilon, epsilonL, fs9, E9, dh9, key);
            
            T1s = 1; % So that while loop starts the first time
            T2s = 0;
            while T1s + T2s > 0
                % Try transition:
                % [newcells, newlocs, T1s, T2s, tries] = transition(cells, locs, L, coeffs, A0, lowdist)
                [newcells9, newlocs9, T1s, T2s, tries] = transition(newcells9, newlocs9, L9, coeffs, A0, lowdist, E9);
                %             disp(['T1s = ', num2str(T1s), ' T2s = ', num2str(T2s), ' Tries = ', num2str(tries)])
                % Do energy minimization:
                [E9, ~, ~, ~, Atot9, Ptot9, dh9] = cellenergies(L9, A0, coeffs, newcells9, newlocs9);
                fs9 = cellforces(L9, A0, coeffs, newcells9, newlocs9, Atot9, Ptot9);
                [newlocs9, Evals9, L9] = stpdescent(newcells9, newlocs9, L9, coeffs, A0, epsilon, epsilonL, fs9, E9, dh9, key);
                %             disp(['cells = ', num2str(length(newcells9))])
            end
%             disp(num2str(i));
        end
    end
    figure(j)
    locsstore{j} = newlocs9;
    cellstore{j} = newcells9;
    Lstore{j} = L9;
    drawpolys(newlocs9, newcells9, L9)
    title([' Full Model Case #: ', num2str(j), ' with 72 division'])
end


%% Output 11 Calculate and Plot a histogram of # sides per histogram
% experimental data: 
exp_polys = [1, 6.78, 34.61, 38.28, 14.28, 2.17, 0.06] / 100;
exp_polys_err = [0.77, 4.176, 4.06, 6.29, 3.36, 1.76, 0.24] / 100;
 
for i = 1:3
    sides{i} = [0];
    hcell = cellstore{i};
    lencells = length(hcell);
    for j = 1:lencells
        [~, numsides] = size(hcell{j});
        sides{i} = [sides{i} ; numsides];
    end
    sides{i} = sides{i}(2:end);
    avgsides{i} = mean(sides{i});
    figure
    hold on
    [counts{i}, centers{i}] = hist(sides{i}, 3:9); %min(sides{i}):max(sides{i})
    bar(centers{i}, counts{i}./lencells, 'Linewidth', 3)
    errorbar(3:9, exp_polys, exp_polys_err, ...
    'o-', 'Color', [0.3,0.7,0.3], 'Linewidth', 3);
    title(['Output 11: Histogram of number of sides of total cells for case: ', num2str(i)])
    legend('simulation', 'experimental')
    ylabel('Number of cells')
    xlabel('Number of sides')
end

% % experimental data: 
% exp_polys = [1, 6.78, 34.61, 38.28, 14.28, 2.17, 0.06] / 100;
% exp_polys_err = [0.77, 4.176, 4.06, 6.29, 3.36, 1.76, 0.24] / 100;
% errorbar(3:9, exp_polys, exp_polys_err, ...
%     'o-', 'Color', [0.3,0.7,0.3], 'Linewidth', 3);




%% Output 12 Calculate and Plot average area per polygon class
% Experimental data: 
exp_areas = [0.56, 0.82, 1.08, 1.36, 1.52];
exp_areas_err = [0.02, 0.01, 0.01, 0.02, 0.05];


for i = 1:3
%    [E6, EA6, ET6, EP6, Atot6, Ptot6, ~] = cellenergies(L, A0, coeffs, cells, newlocs6); 
    [E12{i}, ~, ~, ~, Atot12{i}, Ptot12{i}, ~] = cellenergies(Lstore{i},A0, casevals(i,:), cellstore{i}, locsstore{i}); 
    Aall{i} = mean(Atot12{i});
    
    for j = 4:8
        is = ismembc(sides{i},j);
        areas = Atot12{i}(is);
        javg{j} = mean(areas);    
        
    end       
    Aavg{i} = javg;

    figure
    hold on
%     [counts{i}, centers{i}] = hist(sides{i}, 3:9); %min(sides{i}):max(sides{i})
    plot(4:8, cell2mat(Aavg{i})./Aall{i}, 'Linewidth', 3)
    errorbar(4:8, exp_areas, exp_areas_err, ...
    'o-', 'Color', [0.3, 0.7, 0.3], 'Linewidth', 2);
    title(['Output 12: Average area per polygon class for case: ', num2str(i)])
    legend('simulation', 'experimental') 
    ylabel('<A_n >/<A>')
    xlabel('Number of Sides')

end

%% Output 13 Calculate the shape index for each of the cases (I, II, III)

shapeindex = [-1.5, 0, 4.25];

for i = 1:3
    Afilter = sqrt( Atot12{i}(Atot12{i} > 0) );
    pfilter = Ptot12{i}(Atot12{i} > 0); 
    p0{i} = mean(pfilter./Afilter);
 
end


%% Discussion of Output 13: 
% When I ran this for my study (it might change with each division loop), I
% got that for Case I p0 = 3.87, which is a little higher than the critical
% value of 3.81, so I would say that maybe that state is glassy. The shape
% index for Case II was p0 = 3.9529, which I think puts it into the area
% for fluid behavior, and Case III was p0 = 4.2817, which puts it into the
% fluid behavior. The only value that was close to the theoretical value
% was for Case III, but I'm not sure how the index could be = 0 for Case II
% or a negative value for Case I. 




