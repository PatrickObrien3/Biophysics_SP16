%% Parameters
dt = 0.1;
r0 = 1;
rc =0.1;
rho = 1.5;
v0 = 0.5;
L = 6;
beta = 100;
etas = 0.50:0.02:0.7;
Nsteps = 2000;

% Number of steps between visualization
visualize_steps = 100;

% Calculated parameters
N = rho * L * L;
disp('N =');
disp(N);

% Particle radius to draw
radii = ones(N, 1) .* r0/2;


%% Molecular Dynamics

% Basic setup
rs = rand(N, 2) * L;
vs = randn(N, 2);
vnorm = sqrt(sum(vs'.^2))';
vs = vs .* v0 ./ [vnorm, vnorm];

% Draw the circles
figure(1);
clf;
title(0);
plot(mod(rs(:, 1), L), mod(rs(:, 2), L), 'o');

phis = zeros(length(etas), Nsteps);

tstart = tic;
for i=1:length(etas)
    start_eta = tic;
    eta = etas(i);
    % Now we do the MD loop
    
    for j = 1:Nsteps
        vs = vicsekvelocity(v0, r0, rc, eta, beta, L, rs, vs);
        rs = rs + vs * dt;
        phis(i, j) = sqrt(sum(mean(vs).^2)) ./ v0;
        % Store the energies

        % Draw the circles again
        if mod(j, visualize_steps) == 0
            clf;
            plot(mod(rs(:, 1), L), mod(rs(:, 2), L), 'o');
            axis square;
            axis equal;
            xlim([0, L]);
            ylim([0, L]);
            title(sprintf('eta %.2f, j=%d', eta, j));
            drawnow
            pause(0.01);
        end
    end
    toc(start_eta);
end
toc(tstart);

% calculate the <phi> vs eta
figure(2);
%clf;
hold on;
phi_ave = mean(phis, 2);
plot(etas, phi_ave);


